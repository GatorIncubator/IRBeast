Extensive support for Python list prompts             formatting and colors


